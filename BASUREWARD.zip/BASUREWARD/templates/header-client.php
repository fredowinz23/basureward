<!-- https://demos.adminmart.com/premium/bootstrap/modernize-bootstrap/package/html/main/index.html -->
<?php
session_start();
include_once($ROOT_DIR . "config/database.php");
include_once($ROOT_DIR . "config/Models.php");

$category_list = category()->list();

if (isset($_SESSION["user_session"])) {
  $userId = $_SESSION["user_session"]["Id"];
  $cartTotal = cart()->count("userId=$userId");
}

?>

<style media="screen">
  .badge{
    background:red;color:white;padding:3px;border-radius:10px
  }
  .header-background{
    background: url('../templates/background-client.jpg');
    background-size: 100%;
  }
</style>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>boquet</title>
  <link rel="shortcut icon" type="image/png" href="<?=$ROOT_DIR;?>templates/assets/images/logos/favicon.png" />
  <link rel="stylesheet" href="<?=$ROOT_DIR;?>templates/assets/css/styles.min.css" />
</head>

<body>

      <!--  Header End -->
      <div class="container-fluid" style="height:100px;">
        <div class="card mt-3 header-background">
          <div class="card-body">

            <nav class="navbar navbar-expand-lg">
              <div class="container-fluid">
                <a class="navbar-brand" href="index.php">
                  Home
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Category
                      </a>
                      <ul class="dropdown-menu">
                        <?php foreach ($category_list as $row): ?>
                          <li><a class="dropdown-item" href="index.php?catId=<?=$row->Id?>"><?=$row->name;?></a></li>
                        <?php endforeach; ?>
                      </ul>
                    </li>
                    <?php if (isset($_SESSION["user_session"])): ?>
                      <li class="nav-item">
                        <a class="nav-link" href="cart.php">My Cart
                          <?php if ($cartTotal>0): ?>
                            <span class="badge"><?=$cartTotal?></span>
                          <?php endif; ?>
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="purchase-history.php">Purchase History</a>
                      </li>
                        <li class="nav-item">
                          <a class="nav-link" href="../auth/process.php?action=user-logout">Log Out</a>
                        </li>
                      <?php else: ?>
                        <li class="nav-item">
                          <a class="nav-link" href="../auth/login.php">Log In</a>
                        </li>
                          <li class="nav-item">
                            <a class="nav-link" href="../auth/register.php">Sign Up</a>
                          </li>
                    <?php endif; ?>
                  </ul>
                  <form class="d-flex" role="search" action="index.php" method="get">
                    <input class="form-control me-2" name="key" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-success" type="submit">Search</button>
                  </form>
                </div>
              </div>
            </nav>

          </div>
        </div>




        <!-- Modal -->
        <div class="modal fade" id="loginWarningModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Warning</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
               <a href="../auth/login.php">Click here to login</a>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
