
      </div>
    </div>
  </div>



  <script src="<?=$ROOT_DIR;?>templates/assets/libs/jquery/dist/jquery.min.js"></script>
  <script src="<?=$ROOT_DIR;?>templates/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?=$ROOT_DIR;?>templates/assets/js/sidebarmenu.js"></script>
  <script src="<?=$ROOT_DIR;?>templates/assets/js/app.min.js"></script>
  <script src="<?=$ROOT_DIR;?>templates/assets/libs/apexcharts/dist/apexcharts.min.js"></script>
  <script src="<?=$ROOT_DIR;?>templates/assets/libs/simplebar/dist/simplebar.js"></script>
  <script src="<?=$ROOT_DIR;?>templates/assets/js/dashboard.js"></script>

</body>

</html>


<script type="text/javascript">
$(function () {

  <?php if ($success): ?>
    Swal.fire({
      title: "Success!",
      text: "<?=$success?>",
      icon: "success"
    });
  <?php endif; ?>


  <?php if ($error): ?>
    Swal.fire({
      title: "Error!",
      text: "<?=$error?>",
      icon: "error"
    });
  <?php endif; ?>


  });

</script>
