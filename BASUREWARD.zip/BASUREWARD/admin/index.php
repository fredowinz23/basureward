<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header.php";

?>


<h4 class="text-center">Dash Board</h4>


<?php include $ROOT_DIR . "templates/footer.php"; ?>
