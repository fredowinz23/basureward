$(function () {

    $("#btn-add-contact").on("click", function (event) {

      $("#addContactModal #btn-add").show();
      $("#addContactModal #btn-edit").hide();
      $("#addContactModal").modal("show");
    });

  });
