﻿# Host: localhost  (Version 5.5.5-10.1.34-MariaDB)
# Date: 2024-01-11 18:37:14
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "account"
#

DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `Id` tinyint(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Inactive',
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totalPurchase` double DEFAULT '0',
  `address` text COLLATE utf8mb4_unicode_ci,
  `isDeleted` int(11) DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;

#
# Data for table "account"
#

INSERT INTO `account` VALUES (1,'admin','1234','John','Doe','Active','Admin',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,1),(2,'ace','derrama','ace','derrama','Active','Customer','2023-11-26',NULL,NULL,NULL,NULL,NULL,0,NULL,0),(3,'cyrus','serna','cyrus','serna','Active','Customer','2023-12-10',NULL,NULL,NULL,'09076205057','sernasy917@gmail.com',0,'bacolod city',0),(4,'sunny','sun','sunny','domingo','Active','Staff','2023-12-10',NULL,NULL,NULL,NULL,NULL,0,NULL,0),(5,'admin2','489867','12','12','Inactive','Admin','2023-12-22',NULL,NULL,NULL,NULL,NULL,0,NULL,0);
